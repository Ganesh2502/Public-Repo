// Dark mode toggle
(function(){const k='secore-theme';const r=document.documentElement;const s=localStorage.getItem(k);if(s)r.className=s;})();
